/* File : nlgclu.h */
/* Copyright (c) 2015, Yves Lepage */

extern void nlgclu_in_C(char *fileA, char *fileB, char *clufile, int minsize, int maxsize, int verbose, int lineout, int focus) ;

